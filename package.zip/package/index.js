/**
 * Example problem with existing solution and passing test.
 * See problem 0 in the spec file for the assertion
 * @returns {string}
 */
exports.example = () => 'hello world';

/**
 * @param {[string]} keys 
 * @param {[Object]} data 
 * @returns {[Object]}
 */
exports.stripPrivateProperties = (keys, data) => {
    return data.map(item =>
        Object.keys(item).filter(key => !keys.includes(key)).reduce((newItem, key) => {
            newItem[key] = item[key];
            return newItem;
        }, {}));
};

/**
 * @param {string} key 
 * @param {[Object]} data 
 * @returns {[Object]}
 */
exports.excludeByProperty = (key, data) => {
    return data.filter(item => !(key in item));
};

/**
 * @param {[{objects: [{val: number}]}]} data 
 * @returns {[Object]}
 */
exports.sumDeep = (data) => {
    return data.map(item =>
        ({ objects: item.objects.reduce((acc, value) => acc + value.val, 0) })
    );
};

/**
 * @param {{color: [number]}} colorToStatus 
 * @param {[{status: number}]} data 
 * @returns {[Object]}
 */
exports.applyStatusColor = (colorToStatus, data) => {
    // Lets prepare the association Object for fast search of color for a given status code:
    let statusToColor = {};
    Object.keys(colorToStatus).forEach(color => {
        colorToStatus[color].forEach(status => statusToColor[status] = color);
    });
    //Lets do the search and write the search result into a new object:
    return data.reduce((acc, value) => {
        const color = statusToColor[value.status];
        if (color) {
            acc.push({ status: value.status, color });
        }
        return acc;
    }, []);
};

/**
 * @param {function(string, string)} greetingFunction 
 * @param {string} greeting 
 * @returns {[Object]}
 */
exports.createGreeting = (greetingFunction, greeting) => {
    return (name) => greetingFunction(greeting, name);
};

/**
 * @param {Object} defaults 
 * @returns {function({Object})}
 */
exports.setDefaults = (defaults) => {
    return (data) => ({...defaults, ...data});
};

/**
 * @param {string} userName 
 * @param {Object} services 
 * @returns {Object}
 */
exports.fetchUserByNameAndUsersCompany = async (userName, services) => {
    const [users, status] = await Promise.all([services.fetchUsers(), services.fetchStatus()]);
    const user = users.find(({ name }) => name === userName);
    const company = await services.fetchCompanyById(user.companyId);
    return ({user, status, company})
};